

import java.util.Comparator;

/**
 * VOP ReEksamen F16
 * Kodeskelet til opgave 4c
 * @author erso
 */
public class CommonNamesComparator implements Comparator<CommonName> {

    /*@Override
    public int compare(CommonName o1, CommonName o2) {
    int girlsVsBoys = o2.getTotal() - o1.getTotal();
    if (girlsVsBoys != 0) {
    return girlsVsBoys;
    }
    return o2.getName().compareTo(o1.getName());
    }*/
    
    @Override
    public int compare(CommonName o1, CommonName o2){
        
        int compareNames = o1.getName().compareTo(o2.getName());
        
        return compareNames;
    }

}
