

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 * VOP ReEksamen F16
 * Kodeskelet til opgave 4b
 * @author erso
 */
public class GirlsAndBoys {

    private Map<String, Integer> girlsMap;
    private Map<String, Integer> boysMap;
    private Set<CommonName> commonSet;

    public GirlsAndBoys() {
        boysMap = createNameMap(new File("Boys.txt"));
        girlsMap = createNameMap(new File("Girls.txt"));
    }

    private Map<String, Integer> createNameMap(File file) {
        Map<String, Integer> tempMap = new HashMap<>();
        try{
            Scanner fileScanner = new Scanner(file);
            
            while (fileScanner.hasNextLine()){
                String[] line = fileScanner.nextLine().split("\t");
                
                int placering2014 = Integer.parseInt(line[0]);
                String navn = line[1];
                int antal = Integer.parseInt(line[2]);
                int placering2013 = Integer.parseInt(line[3]);
                           
                tempMap.put(navn, antal);
                
            }
            
            fileScanner.close();
            
        } catch(FileNotFoundException e){
            e.printStackTrace();
        }
        return tempMap;
    }

    public void makeCommonNames() {
        commonSet = new TreeSet<>(new CommonNamesComparator());
        
        for ( String key : boysMap.keySet() ) {
            if (girlsMap.containsKey(key)) {
                commonSet.add(new CommonName(key, girlsMap.get(key), boysMap.get(key)));
            }
        }
        
    }

    @Override
    public String toString() {
        String st = commonSet.toString();
        st = st.substring(1);
        st = st.substring(0, st.length() - 1);
        st = st.replace(", ", "");
        return st;
    }

    public void sortCommonByName(Comparator<CommonName> comparator) {
        Set newSet = new TreeSet<>(new CommonNamesComparator());
        
        newSet.addAll(commonSet);
        
        commonSet = newSet;
        
    }

    public void write2file(File f) {
        
        PrintWriter printWriter = null;
        try {
            
            printWriter = new PrintWriter(f);
            
            for (CommonName commonName : commonSet) {
                
                printWriter.println(commonName.toString());
            }
        } catch (IOException e){
            e.printStackTrace();
        } finally {
            printWriter.close();
        }
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GirlsAndBoys gAndB = new GirlsAndBoys();
        gAndB.makeCommonNames();

        System.out.println("Common Names sort by total:\n" + gAndB.toString());
        gAndB.write2file(new File("CommonSortByNumber.txt"));

        //gAndB.sortCommonByName(new CommonNamesComparator());
        System.out.println("Common Names sort by name:\n" + gAndB.toString());
//        gAndB.write2file(new File("CommonSortByName.txt"));    
    }


}
