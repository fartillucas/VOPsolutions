/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package circularbuffer.solution;

import java.util.Arrays;

/**
 *
 * @author erso Created on 08-02-2010, 09:33:34
 */
class CircularBuff {

    private Integer [] buf;
    private int size;
    private int putIndex = 0;
    private int getIndex = 0;
    //boolean valueSet = false;

    public CircularBuff(int size){
        buf = new Integer[size];
        this.size = size;
        System.out.println(this);
    }

    synchronized int get() {   // Kaldes af Consumer
        //System.out.println(Thread.currentThread().getName()+" waiting");
        while (buf[getIndex] == null) {   // Der er ingen data endnu
            System.out.println("*** Buffer empty ****");
            try {
                wait();  //Venter på notify() fra en Producer
            } catch (InterruptedException e) {
                System.out.println("InterruptedException caught");
            }
        }          
        int value = buf[getIndex];  // Producer har lagt data i bufferen og sendt notify()
        buf[getIndex] = null;       // Consumer fjerner data
        System.out.println(Thread.currentThread().getName()+"\tGot: " + getIndex + ": " + value);
        getIndex = (getIndex+1) % size;   // Cirkulaert gennemløb af bufferen
        notify();       // notify ventende Producere
        return value;
    }

    synchronized void put(int n) {   // Kaldes fra Producer
        //System.out.println(Thread.currentThread().getName()+" waiting");
        while (buf[putIndex] != null) {  // Der er ikke plads til ny data
            System.out.println("*** Buffer full ****");
            try {
                wait();   // venter på notify fra en Consumer
            } catch (InterruptedException e) {
                System.out.println("InterruptedException caught");
            }
        }
        buf[putIndex] = n;  // Consumer har fjernet data og sendt notify(). Producer laegger ny data ind
        System.out.println(Thread.currentThread().getName()+" Put: " + putIndex+ ": " +n);
        putIndex = (putIndex+1) %size;  // Cirkulaert gennemløb af bufferen
        notify();          // notify ventende Consumers
    }

    public String toString(){
        return "Buff: " + Arrays.toString(buf);
    }
}

