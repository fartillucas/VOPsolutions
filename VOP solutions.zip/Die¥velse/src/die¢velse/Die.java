/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dieøvelse;

import java.util.Random;

/**
 *
 * @author malte
 */
public class Die {
    private int max;
    
    public Die(int max){
        
        if (max < 2) max = 2;
        this.max = max;
    
    }
    
    public int throwDie(){
        Random rnd = new Random();
        return rnd.nextInt(max) + 1  ;
    }
    
}
