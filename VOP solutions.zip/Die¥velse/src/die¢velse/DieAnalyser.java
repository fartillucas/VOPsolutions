/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dieøvelse;



public class DieAnalyser {
    
    int[] diceThrows; 
    
    private int max;
    private int length;
    
    public DieAnalyser(int max, int length) {
        this.max = max;
        this.length = length;
        
    }
    
    public void fillArray(){
        
        diceThrows = new int[length];
        
        Die dice = new Die(max);
        
        for (int i = 0; i < diceThrows.length; i++) {
            diceThrows[i] = dice.throwDie();
        }
    }
    
    @Override
    public String toString(){
        String r = "";
        boolean inRun = false;
        
        for (int i = 0; i < diceThrows.length; i++) {
            
            if (inRun) {
                if (diceThrows[i-1] != diceThrows[i]) {
                    r += ")";
                    inRun = false;
                }
            } else {
                if (i < diceThrows.length -1) {
                    if (diceThrows[i] == diceThrows[i + 1]) {
                        
                        r += "(";
                        inRun = true;
                    } else {
                    
                    }
                } 
                
            }
            
            
            r += diceThrows[i];
            
            r+=",";
            
            
        }
        
        if (inRun) r += ")";
        
        return r;
    }
    
}
