/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dieøvelse;

/**
 *
 * @author malte
 */
public class DieØvelse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Die dice = new Die(6);
        
        DieAnalyser DA = new DieAnalyser(2,6);
        
        DA.fillArray();
        System.out.println(DA.toString());
        
        
    }
    
}
