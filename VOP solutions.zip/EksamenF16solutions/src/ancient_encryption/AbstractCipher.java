/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ancient_encryption;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erso
 */
public abstract class AbstractCipher implements CipherInterface {

    protected int findCharIndex(char ch) {
        for (int i = 0; i < ALPHABETH.length; i++) {
            if (ch == ALPHABETH[i]) {
                return i;
            }
        }
        return -1;  //not found
    }

//    @Override
//    public String readFromFile(String fileName) {
//        File file = new File(fileName);
//        StringBuilder sb = new StringBuilder();
//        try (Scanner sc = new Scanner(file)) {
//            while (sc.hasNextLine()) {
//                sb.append(decrypt(sc.nextLine()));
//                sb.append("\n");
//            }
//
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(AbstractCipher.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return sb.toString();
//    }
//
//    @Override
//    public boolean writeToFile(String message, String fileName) {
//        File file = new File(fileName);
//        try (BufferedWriter bf = new BufferedWriter((new FileWriter(file)))) {
//            bf.write(encrypt(message));
//            bf.flush();
//
//        } catch (IOException ioe) {
//            ioe.printStackTrace();
//            return false;
//        }
//        return true;
//    }

}
