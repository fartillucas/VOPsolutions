/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eksamenf16solutions;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

import ancient_encryption.*;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import rock_paper_scissors.RockScissorPaper;

/**
 *
 * @author erso
 */
public class FXMLDocumentController implements Initializable {

    // Ancient Ciphers
    @FXML
    private TextField originalText;
    @FXML
    private TextField encryptedText;
    @FXML
    private TextField decryptedText;
    @FXML
    private RadioButton atbashRadio;
    @FXML
    private ToggleGroup cryptGroup;
    @FXML
    private Button encryptButton;
    @FXML
    private Button decryptButton;
    @FXML
    private RadioButton ceasarRadio;
    @FXML
    private Spinner<Integer> ceasarSpinner;
    @FXML
    private TextField ceasarText;

    // RockSissorsPaper:
    @FXML
    private Button rockButton;
    @FXML
    private Button paperButton;
    @FXML
    private Button scissorButton;
    @FXML
    private ImageView userChoise;
    @FXML
    private ImageView pcChoise;
    @FXML
    private Label winnerLabel;
    @FXML
    private Label computerLabel;

    // Instance variable
    private CipherInterface crypter;

    private RockScissorPaper rockScissorPaper;
    private Map<String, Image> picMap;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        ceasarSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(
                0, CipherInterface.ALPHABETH.length - 1, CipherInterface.ALPHABETH.length / 2));

        rockScissorPaper = new RockScissorPaper();

        picMap = new HashMap<>();
        picMap.put(RockScissorPaper.HANDS[0], new Image(new File("Rock.png").toURI().toString()));
        picMap.put(RockScissorPaper.HANDS[1], new Image(new File("Scissors.png").toURI().toString()));
        picMap.put(RockScissorPaper.HANDS[2], new Image(new File("Paper.png").toURI().toString()));
    }

    @FXML
    private void cryptHandler(ActionEvent event) {
        Object source = event.getSource();

        if (atbashRadio.isSelected()) {
            crypter = new AtbashCipher();
        } else if (ceasarRadio.isSelected()) {
            int keyValue = ceasarSpinner.isVisible() ? ceasarSpinner.getValue() : new Integer(ceasarText.getText());
            crypter = new CeasarCipher(keyValue);
        }

        if (source == encryptButton) {
            encryptedText.setText(crypter.encrypt(originalText.getText()));
        } else if (source == decryptButton) {
            decryptedText.setText(crypter.decrypt(encryptedText.getText()));
        }

    }

    @FXML
    private void rockPaperScissorHandler(ActionEvent event) {
        Object scr = event.getSource();
        String playerChoise = "";

        if (scr == rockButton) {
            playerChoise = RockScissorPaper.HANDS[0];
        } else if (scr == scissorButton) {
            playerChoise = RockScissorPaper.HANDS[1];
        } else {  // must be paperButton
            playerChoise = RockScissorPaper.HANDS[2];

        }
        rockScissorPaper.play(playerChoise);

        computerLabel.setText("Computer: " + rockScissorPaper.getComputer());

        winnerLabel.setText(rockScissorPaper.getWinner());

        userChoise.setImage(picMap.get(playerChoise));
        pcChoise.setImage(picMap.get(rockScissorPaper.getComputer()));
        
    }

}
