/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rock_paper_scissors;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author erso
 */
public class RockScissorPaper {

    public final static String[] HANDS = new String[]{"Sten", "Saks", "Papir"};
    private static Random generator = new Random();

    private String player;
    private String computer;

    private void computerHand() {
        computer = HANDS[generator.nextInt(3)];
    }



    public void play(String playerHand) {
        computerHand();
        player = playerHand;
    }

    public String getWinner() {
        if (player.equals(computer)) {
            return "Uafgjort!";
        } else if (player.equals("Sten") && computer.equals("Saks")
                || player.equals("Saks") && computer.equals("Papir")
                || player.equals("Papir") && computer.equals("Sten")) {
            return ("Du vinder!");

        } else {
            return "Computeren vinder!";
        }
    }

    public String getPlayer() {
        return player;
    }

    public String getComputer() {
        return computer;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        RockScissorPaper play = new RockScissorPaper();
        Scanner sc = new Scanner(System.in);

        try {
            while (true) {
                System.out.println("[0]Sten, [1]Saks or [2]Papir ?");
                play.play(HANDS[sc.nextInt()]);
                System.out.println("Dig: "+play.getPlayer() +"\tComputer: "+play.getComputer());
                System.out.println("Og vinderen er: " + play.getWinner() +"!");
            }
        } catch (Exception ex) {
            System.err.println("Illigalt input! Game over!");
        }

    }

}
