/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade.singleton;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

//import shape_domain.ShapeFacade;
import opg4_poly_solution.ShapeFacade;

/**
 *
 * @author erso
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private RadioButton ellipseRadio;
    @FXML
    private RadioButton rectangleRadio;
    @FXML
    private RadioButton circleRadio;
    @FXML
    private RadioButton squereRadio;
    @FXML
    private ToggleGroup ShapeToggle;
    @FXML
    private TextField para1;
    @FXML
    private TextField para2;
    @FXML
    private Button infoButton;
    @FXML
    private TextArea resultArea;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ellipseRadio.setUserData(ShapeFacade.SHAPES.ELLIPSE);
        rectangleRadio.setUserData(ShapeFacade.SHAPES.RECTANGLE);
        circleRadio.setUserData(ShapeFacade.SHAPES.CIRCLE);
        squereRadio.setUserData(ShapeFacade.SHAPES.SQUERE);
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        String result = "";
        ShapeFacade.SHAPES shape = (ShapeFacade.SHAPES) ShapeToggle.getSelectedToggle().getUserData();
        double p1 = Double.valueOf(para1.getText());
        if (shape == ShapeFacade.SHAPES.CIRCLE || shape == ShapeFacade.SHAPES.SQUERE) {

            result = ShapeFacade.getInstance().getShapeInfo(shape, new double[]{p1});
        } else {
            double p2 = Double.valueOf(para2.getText());
            result = ShapeFacade.getInstance().getShapeInfo(shape, new double[]{p1, p2});
        }

        resultArea.appendText(result + "\n");

//resultArea.appendText(text);
    }

    @FXML
    private void handleRadio(ActionEvent event) {
        ShapeFacade.SHAPES shape = (ShapeFacade.SHAPES) ShapeToggle.getSelectedToggle().getUserData();
        if(shape == ShapeFacade.SHAPES.CIRCLE || shape == ShapeFacade.SHAPES.SQUERE){
            para2.setVisible(false);
        } else{
             para2.setVisible(true);
        }

//        if (event.getSource() == ellipseRadio || event.getSource() == rectangleRadio) {
//            para2.setVisible(true);
//        } else {
//            para2.setVisible(false);
//        }
    }

}
