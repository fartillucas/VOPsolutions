package lektion.pkg03_01;

/**
 * Udleveret kodeskelet til VOP re-eksamen 20. august 2014
 *
 * @author erso
 */
public class UrbanPopulation implements Comparable<UrbanPopulation>{

    private String name;
    private int pop2008;
    private int pop1980;
    
    public UrbanPopulation(String name, int pop1980, int pop2008) {
        this.name = name;
        this.pop1980 = pop1980;
        this.pop2008 = pop2008;
    }
    
    private int getDiff() {
        return this.pop2008 - this.pop1980;
    }
    
    @Override
    public String toString() {
        return this.name + " 1980: " + this.pop1980 + " 2008: " + this.pop2008 + " Dif: " + getDiff() + "\n";
    }

    
    @Override
    public int compareTo(UrbanPopulation otherCountry) {
        int diff = this.getDiff() - otherCountry.getDiff();
        
        if (diff != 0) {
            return diff;
        }
        
        return this.name.compareTo(otherCountry.name);
    }

 }
