package lektion.pkg03_01;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * Udleveret kodeskelet til VOP re-eksamen 20. august 2014
 *
 * @author erso
 */
public class UrbanPopulationStatistics {

    private Set<UrbanPopulation> popSet;
    private File file;

    public UrbanPopulationStatistics(String fileName) {
        // Initialisering af variable
        this.popSet = new TreeSet<>();
        this.file = new File(fileName);
        readFile();
    }

    private void readFile() {
        // Til indlæsning af data fra file,
        // dannelse af objekter af klassen UrbanPopulation
        // og indsættelse af disse i popSet
        
        Scanner input = null;
        
        try {
            input = new Scanner(new File("C:\\Users\\malte\\Documents\\NetBeansProjects\\Lektion 03\\src\\lektion\\pkg03_01\\ByBefolkning.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
        while(input.hasNext()) {
            String line = input.nextLine();
            
            String[] parameters = line.split("/");
            
            UrbanPopulation country = new UrbanPopulation (
                    parameters[0], 
                    Integer.parseInt(parameters[1]), 
                    Integer.parseInt(parameters[4]));
            
            this.popSet.add(country);
            
        }
        
    }

    
// Udleveret toString() metode, som giver en "pæn" formatering.
    @Override
    public String toString() {
        String s = popSet.toString().replaceAll(", ", "");
        return "UrbanPopulationStatistics:\n" + s.substring(1, s.length() - 1) + "\n";
    }

   
    //Udleveret test-metode
    public static void main(String[] args) {
        UrbanPopulationStatistics stats = new UrbanPopulationStatistics("ByBefolkning.txt");
        System.out.println(stats);
    }

}
