/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opg2_numberplates;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author erso
 */
public class NumberPlates {

    public static final int LENGTH = 7;
    private Map<String, String> districtMap;

    public NumberPlates() {
        districtMap = new HashMap<>();
        readFile();
    }

    private void readFile() {
        Scanner scan = null;
        try {
            File file = new File("Nummerplader.txt");
            scan = new Scanner(file);
            String[] keyVal;
            while (scan.hasNextLine()) {
                keyVal = scan.nextLine().split(":");
                districtMap.put(keyVal[0], keyVal[1]);
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } finally {
            if (scan != null) {
                scan.close();
            }
        }
        System.out.println("Map: " + districtMap);
    }

    public String validate(String plate) {

        if (plate.length() != LENGTH) {
            return "Illegal length!";
        }

        String district = validateDistrict(plate.substring(0, 2).toUpperCase());

        Integer numberPart = Integer.parseInt(plate.substring(2));
        
        String vehicleType = validateVehicleType(numberPart);

        return vehicleType + " fra " + district;
    }

    private String validateDistrict(String districtCode) {
        if (!districtMap.containsKey(districtCode)) {
            return "Kreds findes ikke";
        } else {
            return districtMap.get(districtCode);
        }
    }

    private String validateVehicleType(int number) {
        if (number < 10000) {
            return "Illegalt nummer";
        } else if (number < 20000) {
            return "Motorcykel";
        } else if (number < 46000) {
            return "Privat personvogn";
        } else if (number < 47000) {
            return "Udlejningsvogn";
        } else if (number < 49000) {
            return "Hyrevogn";
        } else if (number < 49900) {
            return "Skolevogn";
        } else if (number < 50000) {
            return "Ambulance el. lign.";
        } else if (number < 85000){
            return "Diverse andre køretøjer";
        }
        
        else {
            return "Illegalt nummer";
        }

    }

    public static void main(String[] arg) {
        NumberPlates pd = new NumberPlates();
                
        System.out.println("KC39078: " + pd.validate("KC39078"));
        System.out.println("kc49900: " + pd.validate("kc49900"));
        System.out.println("KO47078: " + pd.validate("KO47078"));
        System.out.println("EN19022: " + pd.validate("EN19022"));
        System.out.println("EN190220: " + pd.validate("EN190220"));
    }

}
