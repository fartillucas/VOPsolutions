/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package vop.eksamenf14;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import opg2_numberplates.NumberPlates;

/**
 *
 * @author erso
 */
public class FXMLDocumentController implements Initializable {
    
    // Opgave 2
    @FXML
    private TextField plateInputField;
    @FXML
    private Label plateOutputLabel;
    @FXML
    private Button checkPlateButton;
    
    private NumberPlates numberPlates;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        numberPlates = new NumberPlates(); // Opg 2
        
    }    

    @FXML
    private void checkNumberplateHandler(ActionEvent event) {
        String numberPlate = plateInputField.getText();
        plateOutputLabel.setText(numberPlates.validate(numberPlate));
    }

    
}
