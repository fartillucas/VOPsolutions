package opg1_facade;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author erso
 */
public class SpecialNumbers
{

    public SpecialNumbers()
    {
    }
    
    public boolean isEven(int x){
        return x % 2 == 0;
    }
    
    public boolean isPrime(int x){
        int sqrt = (int) Math.sqrt(x) + 1;
        for (int i = 2; i < sqrt; i++) {
            if (x % i == 0) {
                return false;
            }
        }
        return true;
    }
    
    public boolean isPowerOf2(int x){
        double y = Math.log(x)/Math.log(2);
        
        return y == (int)y;    }
    

   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {

        SpecialNumbers sn = new SpecialNumbers();
        int x = 1024;
        int y = 1021;
        System.out.println("Even\t" + x +": " + sn.isEven(x) + "\t" + y + ": " + sn.isEven(y));
        System.out.println("Prime\t" + x +": " + sn.isPrime(x) + "\t" + y + ": " + sn.isPrime(y));
        System.out.println("Pow 2\t" + x +": " + sn.isPowerOf2(x) + "\t" + y + ": " + sn.isPowerOf2(y));

    }
    
}
