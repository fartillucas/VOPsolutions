package opg2_polymorphi;

/**
 *
 * @author erso
 */
public interface CheckerInterface
{
    boolean check(int i);
    
}
