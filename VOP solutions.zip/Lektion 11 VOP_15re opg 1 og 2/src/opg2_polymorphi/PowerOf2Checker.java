
package opg2_polymorphi;

/**
 *
 * @author erso
 */
public class PowerOf2Checker implements CheckerInterface{

    @Override
    public boolean check(int i)
    {
        double y = Math.log(i)/Math.log(2);
        
        return y == (int)y;
    }

}
