/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opg2vowels;

/**
 *
 * @author erso
 */
public class UpperCaseVowels {
    public static final String VOWELS = "aAeEiIoOuUyYæÆøØåÅ";
    
    // Udelad filtreringen ?
    public String filter(String original){
        StringBuilder sb = new StringBuilder();
        for(char c : original.toCharArray()){
            if(Character.isWhitespace(c) || Character.isLetterOrDigit(c)){
                sb.append(c);
            }
        }
        
        return sb.toString();
    }
    
    private boolean isVowel(char ch){
        return VOWELS.indexOf(ch) > -1;
    }
    
    public String makeUpperCaseVowels(String in){
        StringBuilder sb = new StringBuilder();
        for(char ch : in.toCharArray()){
            if (isVowel(ch)){
                sb.append(Character.toUpperCase(ch));
            }
            else{
                sb.append(Character.toLowerCase(ch));
            }
        }
        return sb.toString();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String input = "Her testes opg. 2a ved re-eksamen forårssemesteret 2016!\nKorrekt løsning giver 7%.";
        System.out.println("Original: " + input);
        String result = new UpperCaseVowels().makeUpperCaseVowels(input);
        System.out.println("Result  : " + result);
    }
    
}
