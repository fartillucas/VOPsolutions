package opg3company;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author erso
 */
public class CompanyDriver {
    
    private List<Employee> employees;

    public CompanyDriver() {
        employees = new ArrayList<>();
    }
    
    public void addEmployee(Employee employee){
        employees.add(employee);
    }
    
    public List<Employee> getEmployees() {
        return employees;
    }
    
    public void makeEmployees(){
        addEmployee(new SalariedEmployee("John", "Smith", "111-11-1111", 800.00));
        addEmployee(new HourlyEmployee("Karen", "Price", "222-22-2222", 16.75, 40));
        addEmployee(new CommissionEmployee("Sue", "Jones", "333-33-3333", 10000, .06));
        addEmployee(new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444", 5000, .04, 300));        
    }


    public static void main(String[] args) {
        CompanyDriver driver = new CompanyDriver();
        driver.addEmployee(new SalariedEmployee("John", "Smith", "111-11-1111", 800.00));
        driver.addEmployee(new HourlyEmployee("Karen", "Price", "222-22-2222", 16.75, 40));
        driver.addEmployee(new CommissionEmployee("Sue", "Jones", "333-33-3333", 10000, .06));
        driver.addEmployee(new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444", 5000, .04, 300));
 
        for(Employee emp : driver.getEmployees()){
            System.out.println(emp.toString() + "\tEarns " + emp.earnings());
        }
    }

    
}
