package opg3company;

public class HourlyEmployee extends Employee {

    private double wage;
    private double hours;

    public HourlyEmployee(String firstName, String lastName,
            String socialSecurityNumber, double wage, double hours) {
        super(firstName, lastName, socialSecurityNumber);

        if (wage < 0.0) {
            throw new IllegalArgumentException(
                    "Hourly wage must be >= 0.0");
        }
        if (hours < 0.0) {
            throw new IllegalArgumentException(
                    "Hours worked must be >= 0.0");
        }
        this.wage = wage;
        this.hours = hours;
    }

    public void setWage(double wage) {
        if (wage < 0.0) 
        {
            throw new IllegalArgumentException(
                    "Hourly wage must be >= 0.0");
        }

        this.wage = wage;
    }

    public double getWage() {
        return wage;
    }

    public void setHours(double hours) {
        if (hours < 0.0)
        {
            throw new IllegalArgumentException(
                    "Hours worked must be >= 0.0");
        }

        this.hours = hours;
    }

    public double getHours() {
        return hours;
    }

    @Override
    public double earnings() {

        return getWage() * getHours();

    }

    @Override
    public String toString() {
        return "HourlyEmployee: " + super.toString() + "\tWage: " + getWage()
                + " Hours worked: " + getHours();
    }
} 

