package opg3company;

public class SalariedEmployee extends Employee {

    private double monthlySalary;

    public SalariedEmployee(String firstName, String lastName,
            String socialSecurityNumber, double monthlySalary) {
        super(firstName, lastName, socialSecurityNumber);

        if (monthlySalary < 0.0) {
            throw new IllegalArgumentException(
                    "Monthly salary must be >= 0.00");
        }

        this.monthlySalary = monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        if (monthlySalary < 0.0) {
            throw new IllegalArgumentException(
                    "Monthly salary must be >= 0.00");
        }

        this.monthlySalary = monthlySalary;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    @Override
    public String toString() {
        return "\nSalariedEmployee: " + super.toString() + "\tMontly salary: " + getMonthlySalary();
    }

    @Override
    public double earnings() {
        return getMonthlySalary();
    }
}
