/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reeksamenideer;

import opg2vowels.UpperCaseVowels;
import opg3company.BasePlusCommissionEmployee;
import opg3company.CommissionEmployee;
import opg3company.CompanyDriver;
import opg3company.Employee;
import opg3company.HourlyEmployee;
import opg3company.SalariedEmployee;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

/**
 *
 * @author erso
 */
public class FXMLDocumentController implements Initializable {

    // Vowels
    @FXML
    private TextArea inputTextField;
    @FXML
    private TextArea resultTextField;
    @FXML
    private Button bigVowelsButton;

    private UpperCaseVowels bigVowels;

    // Company:
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField ssdField;
    @FXML
    private RadioButton monthRadio;
    @FXML
    private ToggleGroup saleryTypeGroup;
    @FXML
    private RadioButton hourRadio;
    @FXML
    private RadioButton commisionRadio;
    @FXML
    private RadioButton baseCommisionRadio;
    @FXML
    private TextField monthlyField;
    @FXML
    private TextField hourlyField;
    @FXML
    private TextField hoursField;
    @FXML
    private TextField salesField;
    @FXML
    private TextField commisionRateField;
    @FXML
    private TextField baseSaleryField;
    @FXML
    private Button saveEmployeeButton;
    @FXML
    private TextArea showEmployeesArea;
    private CompanyDriver company;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bigVowels = new UpperCaseVowels();
        company = new CompanyDriver();
        company.makeEmployees();
    }

    @FXML
    private void handleBigVowels(ActionEvent event) {
        String input = inputTextField.getText();
        String result = bigVowels.makeUpperCaseVowels(input);
        resultTextField.setText(result);
    }

    private void disableCompanyFields() {
        monthlyField.setDisable(true);
        hourlyField.setDisable(true);
        hoursField.setDisable(true);
        salesField.setDisable(true);
        commisionRateField.setDisable(true);
        baseSaleryField.setDisable(true);
    }

    @FXML
    private void companyRadioHandler(ActionEvent event) {
        disableCompanyFields();
        Object src = event.getSource();
        if (src == monthRadio) {
            monthlyField.setDisable(false);
        } else if (src == hourRadio) {
            hourlyField.setDisable(false);
            hoursField.setDisable(false);
        } else if (src == commisionRadio) {
            salesField.setDisable(false);
            commisionRateField.setDisable(false);
        } else {
            salesField.setDisable(false);
            commisionRateField.setDisable(false);
            baseSaleryField.setDisable(false);

        }

    }
    
    private void clearAllEmployeeFields(){
        monthlyField.clear();
        hourlyField.clear();
        hoursField.clear();
        salesField.clear();
        commisionRateField.clear();
        baseSaleryField.clear();        
    }

    @FXML
    private void saveEmployeeHandler(ActionEvent event) {
        Employee employee = null;
        if (monthRadio.isSelected()) {
            int monthlySalery = Integer.parseInt(monthlyField.getText());
            employee = new SalariedEmployee(firstNameField.getText(), lastNameField.getText(), ssdField.getText(), monthlySalery);
        } else if (hourRadio.isSelected()) {
            int hourlySalery = Integer.parseInt(hourlyField.getText());
            int hours = Integer.parseInt(hoursField.getText());
            employee = new HourlyEmployee(firstNameField.getText(), lastNameField.getText(), ssdField.getText(), hourlySalery, hours);
            
        } else if (commisionRadio.isSelected() || baseCommisionRadio.isSelected()) {
            int sales = Integer.parseInt(salesField.getText());
            double rate = Double.parseDouble(commisionRateField.getText());
            if (baseCommisionRadio.isSelected()) {
                int base = Integer.parseInt(baseSaleryField.getText());
                employee = new BasePlusCommissionEmployee(firstNameField.getText(), lastNameField.getText(), ssdField.getText(), sales, rate, base);
            } else {
                employee = new CommissionEmployee(firstNameField.getText(), lastNameField.getText(), ssdField.getText(), sales, rate);
            }
        }
        company.addEmployee(employee);
        clearAllEmployeeFields();
    }

    @FXML
    private void showEmployeesHandler(ActionEvent event) {
        showEmployeesArea.clear();
        List<Employee> employeesList = company.getEmployees();
        for (Employee emp : employeesList) {
            showEmployeesArea.appendText(emp + " Earns " + emp.earnings()+"\n");
        }
    }

}
