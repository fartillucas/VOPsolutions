/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package liang_exercise12_6;

import java.util.Scanner;

/**
 *
 * @author erso
 */
public class Exercise12_06_extended {

    public int parseHex(String hexString) {
        int value = convertHexToDec(hexString.charAt(0));
        for (int i = 1; i < hexString.length(); i++) {
            value = value * 16 + convertHexToDec(hexString.charAt(i));
        }

        return value;
    }

    private int convertHexToDec(char ch) {
        if (ch == 'A') {
            return 10;
        } else if (ch == 'B') {
            return 11;
        } else if (ch == 'C') {
            return 12;
        } else if (ch == 'D') {
            return 13;
        } else if (ch == 'E') {
            return 14;
        } else if (ch == 'F') {
            return 15;
        } else if (ch <= '9' && ch >= '0') {
            return ch - '0';
        } else {
            throw new NumberFormatException("Illegal character: " + ch);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Exercise12_06_extended e12_6ex = new Exercise12_06_extended();
//e12_6ex.convertHexToDec('z');
        Scanner sc = new Scanner(System.in);
        String hex = "";
        while (!hex.equalsIgnoreCase( "quit") ){
            System.out.print("Enter a hex number: ");
            hex = sc.nextLine();
            if (!hex.equalsIgnoreCase( "quit")) {
                try {
                    System.out.println(e12_6ex.parseHex(hex.toUpperCase()));
                } catch (NumberFormatException nef) {
                    System.out.println(hex + " is not a hexnumber!!");
                }
            }
        }
    }

}
