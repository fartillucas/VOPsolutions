/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparable_solution;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 *
 * @author erso
 */
public class PersonSolution implements Comparable<PersonSolution>{
    private String fName;
    private String lName;
    private GregorianCalendar birthDay;
    private double heigth;

    public PersonSolution(String fName, String lName, int bYear, int bMonth, int bDate, double heigth) {
        this.fName = fName;
        this.lName = lName;
        this.birthDay = new GregorianCalendar(bYear, bMonth, bDate);
        this.heigth = heigth;
    }

    @Override
    public String toString() {
        return "fName=" + fName + ", lName=" + lName + ", birthDay=" + birthDay.getTime() + ", height " + heigth+'\n';
    }

    
    @Override
    public int compareTo(PersonSolution o) {
        int r = this.lName.compareTo(o.lName);
        if(r == 0){
            r = this.fName.compareTo(o.fName);
        }
        if(r == 0){
            r = this.birthDay.compareTo(o.birthDay);
        }
        return r;
    }


    public static void main(String[] args) {
        List<PersonSolution> list = new ArrayList<>();
        list.add(new PersonSolution("A", "BB", 1980, 3, 17, 1.87));
        list.add(new PersonSolution("B", "BB", 1980, 3, 8, 1.86));
        list.add(new PersonSolution("A", "AA", 1980, 3, 9, 1.67));
        list.add(new PersonSolution("A", "BB", 1980, 3, 10, 1.67));
        list.add(new PersonSolution("A", "BB", 1980, 3, 1, 1.66));
        list.add(new PersonSolution("A", "CC", 1980, 3, 1, 1.65));
        
        System.out.println(list);
        
        Collections.sort(list);
        System.out.println("\nsorted:\n" +list);
        
//        Collections.sort(list, new Comparator<PersonSolution>(){
//            @Override
//            public int compare(PersonSolution o1, PersonSolution o2) {
//                return Double.compare(o1.heigth, o2.heigth);
//            }
//            
//        });
//        System.out.println("\nsorted on heigth:\n" +list);
        

        Collections.sort(list, new Comparator<PersonSolution>(){
            @Override
            public int compare(PersonSolution o1, PersonSolution o2) {
                int i = Double.compare(o1.heigth, o2.heigth);
                if(i == 0){
                    i = o1.compareTo(o2);
                }
                return i;
            }
            
        });
        System.out.println("\nsorted:\n" +list);
    }
    
}
