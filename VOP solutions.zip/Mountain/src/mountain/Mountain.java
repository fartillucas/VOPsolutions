package Mountain;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author erso 
 *  Udleveret kode skelet med main()-metode til opgave 4, VOP eksamen 10 juni 2016
 */
public class Mountain implements Comparable<Mountain> {

private String name;
    private String height;
    private String prominence;
    private String latitude;
    private String longitude;
    private String range;
    
        public Mountain(String name, String height, String prominence, String latitude, String longitude, String range){
            this.name = name;
            this.height = height;
            this.prominence = prominence;
            this.latitude = latitude;
            this.longitude = longitude;
            this.range = range;
    }

    @Override
    public String toString() {
        return this.name + 
                " h=" + this.height + 
                ", pro=" + this.prominence + 
                ", lat=" + this.latitude + 
                ", long= " + this.longitude + 
                ", ran= " + this.range;
    }

    @Override
    public int compareTo(Mountain o) {
        
        int prominenceDifference = Integer.parseInt(this.prominence) - Integer.parseInt(o.prominence);
        
        if (prominenceDifference != 0) {
            return prominenceDifference;
        }
        
        return Integer.parseInt(this.height) - Integer.parseInt(o.height);
    }
    

    /**
     * @param args
     */
    public static void main(String[] args) {
        // Til test af Mountain-klassen

        //Opg a Test af constructor og toString()
        // NB: \u00B0 er unicode for grade-tegnet
        
        mountain.MountainSet test1 = new mountain.MountainSet();
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("FranskeBjerge.csv"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        while(scanner.hasNextLine()) {
            
            String[] parameters = scanner.nextLine().split(";");
            
            Mountain test2 = new Mountain(
                parameters[0],
                parameters[1],
                parameters[2],
                parameters[3],
                parameters[4],
                parameters[5]
            );
            
            
        }
        
        Mountain m = new Mountain("Mont Ventoux", "1909", "1148", "44\u00B010'26\"", "05\u00B016'42\"", "Alps");
        System.out.println(m);

        // Opg b Test af compareTo()
        Mountain[] testArray = new Mountain[4];
        testArray[0] = new Mountain("Pic du Midi d'Ossau", "2886", "1092", "42\u00B048'22\"", "-00\u00B025'05\"", "Pyrenees");
        testArray[1] = new Mountain("Pic de Bure", "2709", "1268", "44\u00B037'38\"", "05\u00B056'07\"", "Alps");
        testArray[2] = new Mountain("Mont Chaberton", "3131", "1281", "44\u00B057'53\"", "06\u00B045'06\"", "Alps");
        testArray[3] = new Mountain("Pica d'Estats", "3143", "1281", "42\u00B042'43\"", "00\u00B057'23\"", "Pyrenees");

        System.out.println("Usorteret: ");
        System.out.println(Arrays.toString(testArray));

        System.out.println("Sorteret: ");
        Arrays.sort(testArray);
        System.out.println(Arrays.toString(testArray));

    }



}
