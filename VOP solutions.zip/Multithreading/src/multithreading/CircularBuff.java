/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreading;

import java.util.Arrays;

/**
 *
 * @author erso Created on 08-02-2010, 09:33:34
 */
public class CircularBuff {

    private Integer [] buf;
    private int size;
    int putIndex = 0;
    int getIndex = 0;
    boolean valueSet = false;

    public CircularBuff(int size){
        buf = new Integer[size];
        this.size = size;
    }

    // Implementer get() metoden
    public synchronized int get() {
         if(!valueSet)
      try {
         wait();
      } catch(InterruptedException e) {
         System.out.println("InterruptedException caught");
      }
      System.out.println("Got: " + getIndex);
      valueSet = false;
      notify();
      return getIndex;
    }

    // Implementer put() metoden
    void put(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String toString(){
        return "Buff: "+Arrays.toString(buf);
    }


}

