/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pipestream;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.util.Scanner;

/**
 *
 * @author erso Created on 15-02-2010, 10:32:36
 */
public class PipeConsumer implements Runnable{
    private PipedInputStream pis;
    

    public PipeConsumer(PipedInputStream pis) {
        this.pis = pis;
       
    }
    
    @Override
    public void run() {
        try {
            try {
                // Setup a stream to receive primitive data from
                // the PipedInputStream
                DataInputStream DIS = new DataInputStream(pis);
                
                int n = DIS.readInt();
                boolean b = DIS.readBoolean();
                long l = DIS.readLong();
                
                System.out.println("Consumer got: " + n + ", " + b + ", " + l);
            } finally {
                pis.close();
                // Close the streams
                
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }

}
