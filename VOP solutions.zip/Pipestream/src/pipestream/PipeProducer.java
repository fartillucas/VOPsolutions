/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pipestream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 *
 * @author erso Created on 15-02-2010, 10:32:07
 */
public class PipeProducer implements Runnable {

    private int number;
    private boolean bool;
    private long dateAsMillis;
    private PipedOutputStream pos = null;

    public PipeProducer(PipedOutputStream pos) {
        this.pos = pos;
        number = (int) (Math.random() * 1000 -1);
        bool = Math.random() < 0.5;
        dateAsMillis = System.currentTimeMillis();
    }

    @Override
    public void run() {
        try {
            try {
                // Setup a stream to send primitive data over the
                // PipedOutputStream
                DataOutputStream DOS = new DataOutputStream(pos);
                DOS.writeInt(number);
                DOS.writeBoolean(bool);
                DOS.writeLong(dateAsMillis);
                
                System.out.println("Producer has send: " + number + ", " + bool + ", " + dateAsMillis);
            } finally {
                // Close the streams
                pos.close();
            }
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }
}
