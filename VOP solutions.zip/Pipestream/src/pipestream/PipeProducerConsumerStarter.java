/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pipestream;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

/**
 *
 * @author erso   Created on 15-02-2010, 10:19:44
 */
public class PipeProducerConsumerStarter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        PipedOutputStream POS = new PipedOutputStream();
        PipedInputStream PIS = new PipedInputStream(POS);

        PipeProducer producer = new PipeProducer(POS);
        PipeConsumer consumer = new PipeConsumer(PIS);

        new Thread(consumer).start();
        new Thread(producer).start();


    }
}
