/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package danish_towns;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author erso
 */
public class TownStatistics {

    private List<DanishTown> townList;

    public TownStatistics() {
        this.townList = new ArrayList<>();
    }

    @Override
    public String toString() {
        String s = townList.toString();
        return "TownStatistics:\n" + s.substring(1, s.length()-1) + "\n";
    }

    public void sort() {
        Collections.sort(townList);
    }

    public void readFile(String fileName) {
        Scanner scan = null;

        try {
            scan = new Scanner(new File(fileName));

            String[] items;
            int b11;
            int b12;
            while (scan.hasNextLine()) {
                items = scan.nextLine().split(";");
                //System.out.println(items[2]);
                b11 = Integer.parseInt(items[3]);
                b12 = Integer.parseInt(items[4]);
                townList.add(new DanishTown(items[2], b11, b12));
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } finally {
            if (scan != null) {
                scan.close();
            }
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TownStatistics ts = new TownStatistics();
        ts.readFile("DkBefolkning.txt");
        System.out.println("Unsorted " + ts);
        ts.sort();
        System.out.println("Sorted " + ts);

    }

}
