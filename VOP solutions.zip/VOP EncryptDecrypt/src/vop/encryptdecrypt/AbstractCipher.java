/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vop.encryptdecrypt;


/**
 *
 * @author malte
 */
public abstract class AbstractCipher implements CipherInterface {
    
    //Takes a letter from the alphabeat and returns its place in the alphabeat
    public int findCharIndex(char ch){
        
        //For each letter in the alphabeat
        for (int i = 0; i < ALPHABETH.length ; i++) {
            //If the given character match return the index
            if (ch == ALPHABETH[i]) {
                return i;
            }
        }
        //If no match is found return -1
        return -1;
    }
    
}
