/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vop.encryptdecrypt;

/**
 *
 * @author malte
 */
public class AtbashCipher extends AbstractCipher {

    @Override
    public String encrypt(String message) {
        
        //Empty string
        String newString = "";
        
        //Going through each letter
        for (int i = 0; i < message.length(); i++) {
            
            //Declaring the current char.
            char currentChar = message.charAt(i);
            
            //Get the integer value of the character
            int currentIndex = findCharIndex(currentChar);
            
                //If value = -1, char not found.
                if (currentIndex == -1) {
                    //If value not found don't change it. Fx. a space, exclamation etc.
                    newString += currentChar;
                
                } else {
                    //Change the index 
                    int newIndex = ALPHABETH.length - currentIndex -1;
            
                    //add the letter to the string from the index.
                    newString += ALPHABETH[newIndex];
                }
            
            
            
        }
        
        return newString;
        
    }

    @Override
    public String decrypt(String encrypted) {
        
        String newString = "";
        
        for (int i = 0; i < encrypted.length(); i++) {
            
            char currentChar = encrypted.charAt(i);
            
            int currentIndex = findCharIndex(currentChar);
            
            if (currentIndex == -1) {
                
                newString += currentChar;
                
            } else {
                int newIndex = ALPHABETH.length - currentIndex;
            
                newString += ALPHABETH[newIndex];
            }
            
            
            
        }
        
        return newString;
    }
    
}
