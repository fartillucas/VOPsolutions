package election_poll;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author erso
 */
public class PoliticalParty implements Comparable<PoliticalParty>
{

    private char id;
    private String name;
    private double shareOfVotesMay2015;
    private double shareOfVotesElection2011;
    private int seatsMay2015;
    private int seatsElection2011;

    public PoliticalParty(char id, String name, double percentageMay2015, double percentageElection2011, int seatsMay2015, int seatsElection2011)
    {
        this.id = id;
        this.name = name;
        this.shareOfVotesMay2015 = percentageMay2015;
        this.shareOfVotesElection2011 = percentageElection2011;
        this.seatsMay2015 = seatsMay2015;
        this.seatsElection2011 = seatsElection2011;
    }

    public double getShareOfVotesDiff()
    {
        return shareOfVotesMay2015 - shareOfVotesElection2011;
    }

    public int getSeatsDiff()
    {
        return seatsMay2015 - seatsElection2011;
    }

    @Override
    public int compareTo(PoliticalParty o)
    {
        int r = this.getSeatsDiff() - o.getSeatsDiff();
        if (r == 0)
        {
            r = Double.compare(this.getShareOfVotesDiff(), o.getShareOfVotesDiff());
            
        }
        return r;
    }

    public String getName(){
        return name;
    }
    
    @Override
    public String toString()
    {
        return "\n"+ id + " " + String.format("%1$-14s", name) 
                + "Diff: " + String.format("%.1f", getShareOfVotesDiff()) + "%  " + getSeatsDiff() + " man"
                + "\tFV: " + String.format("%.1f",shareOfVotesElection2011) + "% " + seatsElection2011 + " man"
                + "\tPo: " + String.format("%.1f",shareOfVotesMay2015) + "% " + seatsMay2015  + " man";
    }

    public static void main(String[] arg)
    {
        ArrayList<PoliticalParty> l = new ArrayList<>();
        l.add(new PoliticalParty('A', "Socialdem.", 25.3, 24.8, 45, 44));
        l.add(new PoliticalParty('V', "Venstre", 22.5, 26.7, 40, 47));

        System.out.println("Before: " + l);
        Collections.sort(l);
        System.out.println("After : " + l);
    }

}
