package election_poll;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author erso
 */
public class PollAnalyzer
{

    private List<PoliticalParty> partyList;

    public PollAnalyzer()
    {
        this.partyList = new ArrayList<>();
    }

    public List<PoliticalParty> getPartyList()
    {
        return partyList;
    }

    public void readFile(String fileName)
    {

        try (Scanner scan = new Scanner(new File(fileName)))
        {
            char id;
            String name;
            double percMay;
            double percElec;
            int seatsMay;
            int seatsElec;
            String[] line;
            while (scan.hasNextLine())
            {
                line = scan.nextLine().split("\t");
                id = line[0].charAt(0);
                name = line[1];
                percMay = new Double(line[2]);
                percElec = new Double(line[3]);
                seatsMay = new Integer(line[4]);
                seatsElec = new Integer(line[5]);
                partyList.add(new PoliticalParty(id, name, percMay, percElec, seatsMay, seatsElec));
            }

        } catch (FileNotFoundException ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void sortPartyList(){
        Collections.sort(getPartyList());
    }
    
    public Set<PoliticalParty> makeSet(Comparator comp){
        Set<PoliticalParty> set = new TreeSet<>(comp);
        set.addAll(getPartyList());
        return set;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        PollAnalyzer pollAnalyser = new PollAnalyzer();
        String fileName = "epinion12maj.txt";

        pollAnalyser.readFile(fileName);
        System.out.println("Unsorted:" + pollAnalyser.getPartyList());
        
        pollAnalyser.sortPartyList();
        System.out.println("Sorted:" + pollAnalyser.getPartyList());
        
        System.out.println("SortedSet: "+  pollAnalyser.makeSet(new PollComparator()));

    }

}
