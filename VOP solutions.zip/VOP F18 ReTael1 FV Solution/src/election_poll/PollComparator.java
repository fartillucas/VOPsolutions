/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package election_poll;

import java.util.Comparator;

/**
 *
 * @author erso
 */
public class PollComparator implements Comparator<PoliticalParty>{

    @Override
    public int compare(PoliticalParty o1, PoliticalParty o2) {
        return o1.getName().compareTo(o2.getName());
    }
    
}
