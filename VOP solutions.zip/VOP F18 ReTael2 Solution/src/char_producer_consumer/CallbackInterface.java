/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package char_producer_consumer;

import java.util.List;

/**
 *
 * @author erso
 */
public interface CallbackInterface {
    
    
    void updateMessage(int index, Character value);
}
