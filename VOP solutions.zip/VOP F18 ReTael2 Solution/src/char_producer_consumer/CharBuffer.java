package char_producer_consumer;

/**
 *
 * @author erso
 */
public class CharBuffer {


    private Character[] buf;

    private int putIndex;
    private int getIndex;

    private CallbackInterface caller;

    public CharBuffer(int size, CallbackInterface caller) {
        buf = new Character[size];
        this.caller = caller;
    }

    public synchronized void put(Character ch) {
        while (buf[putIndex] != null) {
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("InterruptedException caught");
            }
        }
        buf[putIndex] = ch;
        caller.updateMessage(putIndex, ch);
        putIndex = (putIndex + 1) % buf.length;
        notify();
    }

    public synchronized char get() {
        while (buf[getIndex] == null) {
            try {
                wait();
            } catch (InterruptedException e) {
                System.out.println("InterruptedException caught");
            }
        }
        char value = buf[getIndex];
        buf[getIndex] = null;
        caller.updateMessage(getIndex, null);
        getIndex = (getIndex + 1) % buf.length;
        notify();
        return value;
    }

    public static void main(String[] arg) {
        CallbackInterface caller = new CallbackInterface() {
            @Override
            public void updateMessage(int index, Character value) {
                System.out.println(index + " er opdateret med '" + value + "'");
            }
        };

        CharBuffer rb = new CharBuffer(5, caller);

        CharProducer p1 = new CharProducer(rb);
        CharProducer p2 = new CharProducer(rb);

        CharConsumer c1 = new CharConsumer(rb, "erik");
        CharConsumer c2 = new CharConsumer(rb, "oswald");
        CharConsumer c3 = new CharConsumer(rb, "liselottemargrethe");

        Thread tp1 = new Thread(p1);
        tp1.setDaemon(true);

        Thread tp2 = new Thread(p2);
        tp2.setDaemon(true);

        new Thread(c1).start();
        tp1.start();
        new Thread(c2).start();
        tp2.start();
        new Thread(c3).start();
    }
}
