/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package char_producer_consumer;

/**
 *
 * @author erso
 */
public class CharConsumer implements Runnable {

    private String name;
    private CharBuffer buf;

    public CharConsumer(CharBuffer buf, String name) {
        this.buf = buf;
        this.name = name;

    }

    @Override
    public void run() {
        while (!name.equals(name.toUpperCase())) {
            char ch = buf.get();
            name = name.replace(ch, Character.toUpperCase(ch));
            System.out.println(name);
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                System.out.println(ex);
            }
        }

    }

}
