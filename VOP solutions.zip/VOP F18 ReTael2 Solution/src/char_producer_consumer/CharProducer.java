/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package char_producer_consumer;

import java.util.Random;

/**
 *
 * @author erso
 */
public class CharProducer implements Runnable {

    private static final char[] CHARACTERS = {'a', 'b', 'c', 'd', 'e', 'f', 'g',
        'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
        'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

    private CharBuffer buf;

    public static Random generator = new Random();

    public CharProducer(CharBuffer buf) {
        this.buf = buf;
    }

    @Override
    public void run() {

        while (true) {
            char ch = CHARACTERS[generator.nextInt(CHARACTERS.length)];
            System.out.println("Prod: " + ch);
            buf.put(ch);
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                System.out.println(ex);
            }
        }
    }

}
