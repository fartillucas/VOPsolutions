/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vop.f18.retael2.solution;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import char_producer_consumer.CallbackInterface;
import char_producer_consumer.CharConsumer;
import char_producer_consumer.CharProducer;
import char_producer_consumer.CharBuffer;

/**
 *
 * @author erso
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField buffer0;
    @FXML
    private TextField buffer1;
    @FXML
    private TextField buffer2;
    @FXML
    private TextField buffer3;
    @FXML
    private TextField buffer4;
    @FXML
    private Button startProducer;
    @FXML
    private Button startConsumer;
    @FXML
    private TextField producers;
    @FXML
    private TextField consumerNameField;

    private TextField[] bufferFields;

    private int producerCount = 0;
    private int consumerCount = 0;

    private CharBuffer rBuf;
    private CallbackInterface callBack = new CallbackInterface() {

        @Override
        public void updateMessage(int index, Character value) {

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    bufferFields[index].setText(" " + value);
                }
            });
        }
    };

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        rBuf = new CharBuffer(5, callBack);
        bufferFields = new TextField[]{buffer0, buffer1, buffer2, buffer3, buffer4};
    }

    @FXML
    private void producerStartHandler(ActionEvent event) {

        Thread t = new Thread(new CharProducer(rBuf));
        t.setDaemon(true);
        t.start();
        producerCount++;
        producers.setText(" " + producerCount);

    }

    @FXML
    private void consumerStartHandler(ActionEvent event) {
        String name = consumerNameField.getText().toLowerCase();
        if (name.length() > 0) {
            Thread t = new Thread(new CharConsumer(rBuf, name));
            t.setDaemon(true);
            t.start();
        }
        consumerNameField.clear();
    }

}
