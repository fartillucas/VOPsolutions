/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam_fx_gui;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import io_singleton.IO_Singleton;

/**
 *
 * @author erso
 */
public class FXMLDocumentController implements Initializable {

    // Juggler:
    @FXML
    private Button stopJugglerButton;
    @FXML
    private Button startJugglerButton;
    @FXML
    private ImageView jugglerImageView;
    @FXML
    private Slider jugglerSlider;
    @FXML
    private Label label;
    private Image jugglerImages[];
    private Thread jugglerThread;

    // Search Replace:
    @FXML
    private TextField searchField;
    @FXML
    private TextField replaceField;
    @FXML
    private TextArea textArea;
    @FXML
    private Button replaceAllButton;
    @FXML
    private Button openFileButton;
    @FXML
    private Button saveAsButton;

    private FileChooser fileChooser;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Juggler:
        jugglerImages = new Image[4];
        String preFix = "Juggler";
        String postFix = ".jpg";
        for (int i = 0; i < jugglerImages.length; i++) {
            jugglerImages[i] = new Image(new File(preFix + i + postFix).toURI().toString());
        }
        jugglerImageView.setImage(jugglerImages[0]);

        //Search Replace:
        fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File("."));

    }

    @FXML
    private void jugglerButtonHandler(ActionEvent event) {
        if (event.getSource() == startJugglerButton) {
            jugglerThread = new Thread(new JugglerAnimation());
            jugglerThread.setDaemon(true);
            jugglerThread.start();
        } else {
            if (jugglerThread.isAlive()) {
                jugglerThread.interrupt();
            }
        }
    }

    @FXML
    private void replaceButtonHandler(ActionEvent event) {
        String str = textArea.getText().replaceAll(searchField.getText(), replaceField.getText());
        textArea.setText(str);
    }

    @FXML
    private void openFileHandler(ActionEvent event) {
        textArea.clear();
        File inFile = fileChooser.showOpenDialog(null);
        textArea.setText(IO_Singleton.getInstance().readTextFile(inFile));

    }

    @FXML
    private void saveAsFileHandler(ActionEvent event) {
        File outFile = fileChooser.showSaveDialog(null);
        IO_Singleton.getInstance().saveInTextFile(textArea.getText(), outFile);
    }

    private class JugglerAnimation implements Runnable {

        int i = 1;
        int k = 0;

        @Override
        public void run() {

            try {
                while (!Thread.interrupted()) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            jugglerImageView.setImage(jugglerImages[i]);
                            i = (i + 1) % jugglerImages.length;
                            label.setText("Updates: " + (k++));
                        }

                    });
                    Thread.sleep((long) jugglerSlider.getValue());
                }
            } catch (InterruptedException ex) {
                System.out.println("Juggler stopped by interupt!");
            }

        }

    }

}
