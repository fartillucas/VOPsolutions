/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io_singleton;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author erso
 */
public class IO_Singleton {
    //Singleton stuff:
    private static IO_Singleton instance = null;
    
    private IO_Singleton(){}
    
    public static IO_Singleton getInstance(){
        if(instance == null){
            instance = new IO_Singleton();
        }
        return instance;
    }

    // public methodes:
    public String readTextFile(File inFile) {
        StringBuilder sb = new StringBuilder();

        try (Scanner sc = new Scanner(inFile, "UTF-8")) {
            while (sc.hasNext()) {
                String s = sc.nextLine();
                
                sb.append(s);
                sb.append("\n");
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        
        return sb.toString();
    }

    public void saveInTextFile(String text, File outFile) {
        try (FileWriter fw = new FileWriter(outFile)) {
            fw.write(text);
            fw.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        File inFile = new File("HelloWorld.txt");
        
        String original = IO_Singleton.getInstance().readTextFile(inFile);
        System.out.println("Original:\n" + original);
        
        String replaced = original.replaceAll("Hello", "Goodbye");
        System.out.println("Replaced:\n" + replaced);
        
        IO_Singleton.getInstance().saveInTextFile(replaced, new File("World.txt"));
        
    }

}
