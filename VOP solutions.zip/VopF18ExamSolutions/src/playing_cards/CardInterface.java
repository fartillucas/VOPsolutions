/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playing_cards;

/**
 *
 * @author erso
 */
public interface CardInterface {
    // Konstanter for kulørerne Klør, Ruder, Hjerter og Spar (suits in English)
    String[] SUITS = {"CLUBS", "DIAMONDS", "HEARTS", "SPADES"};
    // konstante værdier for es og billedkort. Alle andre kort har pålydende som værdi
    int ACE = 1;
    int JACK = 11;
    int QUEEN = 12;
    int KING = 13;
    // Konstant værdi for antal kort
    int NUMBER_OF_CARDS = 52;
    // Konstant værdi for antal kort en spiller får
    int SIZE_OF_HAND = 13;

}
