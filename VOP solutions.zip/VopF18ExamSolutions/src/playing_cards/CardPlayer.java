/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playing_cards;

import java.util.Arrays;

/**
 *
 * @author erso
 */
public class CardPlayer {

    private String name;
    private Card[] hand;
    private int noOfCards = 0;

    public CardPlayer(String name, int sizeOfHand) {
        this.name = name;
        this.hand = new Card[sizeOfHand];
    }

    public void addCardToHand(Card card) throws Exception {
        if (noOfCards >= hand.length) {
            throw new Exception("To many Cards");

        }
        int i = 0;
        while (i < noOfCards && hand[i].compareTo(card) < 0) {
            i++;
        }
        for (int j = hand.length - 2; j >= i; j--) {
            hand[j + 1] = hand[j];

        }
        hand[i] = card;
        noOfCards++;

//        System.out.println("Hand: " + Arrays.toString(hand));
    }

    @Override
    public String toString() {
        return name + ": " + Arrays.toString(hand);
    }

}
