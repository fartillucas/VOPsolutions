/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playing_cards;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erso
 */
public class DeckOfCards {
     
    public List<Card> deck;
//    public Stack<Card> deck;
    
    public DeckOfCards(){
        deck = new LinkedList<>();
        
        for(String suit : CardInterface.SUITS){
            for(int i = CardInterface.ACE; i <= CardInterface.KING; i++){
                deck.add(new Card(i, suit));
                
            }
        }
        System.out.println(deck);

        
    }
    
    public void shuffleCards(){
        Collections.shuffle(deck);
        System.out.println("Shuffled:\n" + deck);        
    }
    
    public Card pickCard(){
        if(deck.size() > 0){
            return deck.remove(0);
        }
        else
            return null;
    }
            

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          
        DeckOfCards deck = new DeckOfCards();
        deck.shuffleCards();
        CardPlayer playerA = new CardPlayer("Player A", CardInterface.SIZE_OF_HAND);
        CardPlayer playerB = new CardPlayer("Player B", CardInterface.SIZE_OF_HAND);
        for(int i = 0; i < CardInterface.SIZE_OF_HAND; i++){
            try {
                playerA.addCardToHand(deck.pickCard());
                playerB.addCardToHand(deck.pickCard());
            } catch (Exception ex) {
                Logger.getLogger(DeckOfCards.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(playerA);
        System.out.println(playerB);
        
    }
    
}
